package br.com.senai.infob.primeiro_projeto.models;

public class Conta {
    private int id;

    public int getId() {
        return this.id;
    }

    public void setId(int novo_id){
        this.id = novo_id;
    }
}
