package br.com.senai.infob.primeiro_projeto.models;

public class Corrente {
    private int id;
    private String nome;
    private String senha;
    private int idade;
    private String cidade;
}
