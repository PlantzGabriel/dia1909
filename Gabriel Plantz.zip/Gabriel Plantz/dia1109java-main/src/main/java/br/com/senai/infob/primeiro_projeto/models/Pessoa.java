package br.com.senai.infob.primeiro_projeto.models;

public class Pessoa {
    private int id;
    private String nome;
    private String senha;
    private int idade;
    private String cidade;
}
