package br.com.senai.infob.primeiro_projeto.repositories;

public class DiretorRepository {
    
}
