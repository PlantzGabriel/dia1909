package br.com.senai.infob.primeiro_projeto.primeiro_projeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroProjetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
