package com.senai.infob.dvdrental.controllers;

public class StaffController {
    
}
