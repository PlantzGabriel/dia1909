package com.senai.infob.dvdrental.models;

import java.time.LocalDateTime;

public class City {
    private int cityId;
    private String country;
    private LocalDateTime lastUpdate;
    public City() {
    }
    public City(int cityId, String country, LocalDateTime lastUpdate) {
        this.cityId = cityId;
        this.country = country;
        this.lastUpdate = lastUpdate;
    }

    public int getCityId() {
        return cityId;
    }

    public void setCityId(int cityId) {
        this.cityId = cityId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(LocalDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
    
}
