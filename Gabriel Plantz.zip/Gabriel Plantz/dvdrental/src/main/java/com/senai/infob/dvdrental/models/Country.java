package com.senai.infob.dvdrental.models;

public class Country {
    
}
