package com.senai.infob.dvdrental.models;

import java.time.LocalDateTime;

public class Customer {
    private int customerId;
    private int storeId;
    private String firstName;
    private String lastName;
    private String email;
    private int addressId;
    private boolean activebool;
    private Float creatDate;
    private LocalDateTime lastUpdate;
    private boolean active;
    public Customer() {
    }
    public Customer(int customerId, int storeId, String firstName, String lastName, String email, int addressId,
            boolean activebool, Float creatDate, LocalDateTime lastUpdate, boolean active) {
        this.customerId = customerId;
        this.storeId = storeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.addressId = addressId;
        this.activebool = activebool;
        this.creatDate = creatDate;
        this.lastUpdate = lastUpdate;
        this.active = active;
    }
    public int getCustomerId() {
        return customerId;
    }
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    public int getStoreId() {
        return storeId;
    }
    public void setStoreId(int storeId) {
        this.storeId = storeId;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public int getAddressId() {
        return addressId;
    }
    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }
    public boolean isActivebool() {
        return activebool;
    }
    public void setActivebool(boolean activebool) {
        this.activebool = activebool;
    }
    public Float getCreatDate() {
        return creatDate;
    }
    public void setCreatDate(Float creatDate) {
        this.creatDate = creatDate;
    }
    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }
    public void setLastUpdate(LocalDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
    public boolean isActive() {
        return active;
    }
    public void setActive(boolean active) {
        this.active = active;
    }
}
