package com.senai.infob.dvdrental.models;

import java.time.LocalDateTime;

public class Inventory {
    private int inventoryid;
    private int filmId;
    private int storeId;
    private LocalDateTime lastUpdate;
    public Inventory() {
    }
    public Inventory(int inventoryid, int filmId, int storeId, LocalDateTime lastUpdate) {
        this.inventoryid = inventoryid;
        this.filmId = filmId;
        this.storeId = storeId;
        this.lastUpdate = lastUpdate;
    }
    public int getInventoryid() {
        return inventoryid;
    }
    public int getFilmId() {
        return filmId;
    }
    public int getStoreId() {
        return storeId;
    }
    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }
}
