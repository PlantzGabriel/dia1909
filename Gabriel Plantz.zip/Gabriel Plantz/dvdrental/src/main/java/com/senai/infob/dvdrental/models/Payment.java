package com.senai.infob.dvdrental.models;

public class Payment {
    private int paymentId;
    private int customerId;
    private int staffId;
    private Float amount;
    private float paymentDate;
    public Payment() {
    }
    public Payment(int paymentId, int customerId, int staffId, Float amount, float paymentDate) {
        this.paymentId = paymentId;
        this.customerId = customerId;
        this.staffId = staffId;
        this.amount = amount;
        this.paymentDate = paymentDate;
    }
    public int getPaymentId() {
        return paymentId;
    }
    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }
    public int getCustomerId() {
        return customerId;
    }
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    public int getStaffId() {
        return staffId;
    }
    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }
    public Float getAmount() {
        return amount;
    }
    public void setAmount(Float amount) {
        this.amount = amount;
    }
    public float getPaymentDate() {
        return paymentDate;
    }
    public void setPaymentDate(float paymentDate) {
        this.paymentDate = paymentDate;
    }
}
