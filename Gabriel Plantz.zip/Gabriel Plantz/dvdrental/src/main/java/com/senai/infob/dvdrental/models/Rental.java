package com.senai.infob.dvdrental.models;

import java.time.LocalDateTime;

public class Rental {
    private int rentalId;
    private Float rentalDate;
    private int inventoryId;
    private int cusromerId;
    private Float returnDate;
    private int staffId;
    private LocalDateTime lastUpdate;
    public Rental() {
    }
    public Rental(int rentalId, Float rentalDate, int inventoryId, int cusromerId, Float returnDate, int staffId,
            LocalDateTime lastUpdate) {
        this.rentalId = rentalId;
        this.rentalDate = rentalDate;
        this.inventoryId = inventoryId;
        this.cusromerId = cusromerId;
        this.returnDate = returnDate;
        this.staffId = staffId;
        this.lastUpdate = lastUpdate;
    }
    public int getRentalId() {
        return rentalId;
    }
    public void setRentalId(int rentalId) {
        this.rentalId = rentalId;
    }
    public Float getRentalDate() {
        return rentalDate;
    }
    public void setRentalDate(Float rentalDate) {
        this.rentalDate = rentalDate;
    }
    public int getInventoryId() {
        return inventoryId;
    }
    public void setInventoryId(int inventoryId) {
        this.inventoryId = inventoryId;
    }
    public int getCusromerId() {
        return cusromerId;
    }
    public void setCusromerId(int cusromerId) {
        this.cusromerId = cusromerId;
    }
    public Float getReturnDate() {
        return returnDate;
    }
    public void setReturnDate(Float returnDate) {
        this.returnDate = returnDate;
    }
    public int getStaffId() {
        return staffId;
    }
    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }
    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }
    public void setLastUpdate(LocalDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
}
