package com.senai.infob.dvdrental.repositores;

public class CustomerRepositores {
    
}
